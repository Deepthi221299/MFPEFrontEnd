import { Component, OnInit, Input ,ViewChild , ElementRef} from '@angular/core';
import { NgForm } from '@angular/forms';
import { ProceedToBuyService } from 'src/app/services/proceed-to-buy.service';
import { ProductService } from 'src/app/services/product.service';
import { Carts } from '../Models/Carts';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  @ViewChild('searchInput') searchInput!: ElementRef<any>;

  constructor(
    private service: ProductService,
    public cartService: ProceedToBuyService
  ) {}
  displayedColumns: string[] = [
    'Id',
    'Name',
    'Price',
    'Description',
    'Image',
    'Rating',
    'Action',
  ];
  ProductList: any = [];
  searchType: string = 'id';
  searchValue: string ='';
  userId = localStorage.getItem('id');
  userName = localStorage.getItem('username');
  Address = localStorage.getItem('address');
  ModalTitle!: string;
  ActivateaddCartComp!: boolean;
  cart: any = {
    customerId: 0,
    productId: 0,
    quantity: 0,
    zipcode: 0,
    deliveryDate: new Date(),
  };
 
  @Input() searchvalue: string | undefined;

  ngOnInit(): void {
    this.refreshProductList();
  }
  addClick() {
    this.ModalTitle = 'Add to Cart';
    this.ActivateaddCartComp = true;
  }
  addtoCart(productData: any) {
    console.log(productData)
    var cartData : Carts ={
      customerId : 1,
      productId : productData.productId,
      quantity:1,
      zipcode : 523001,
      deliveryData : new Date(),
      vendorId: 0,
      cartId : 0
    }
    this.cartService.addCarts(cartData).subscribe((data) => {
    });
  }
//   description: "Budjet Friendly"
// imageName: "product1.jpg"
// price: 5999
// productId: 1
// productName: "Redmi"
// rating: 3

  onSubmit(form: NgForm) {
    this.service.getProductById(form.value).subscribe((data: any) => {
      this.ProductList = data;
    });
  }
  refreshProductList() {
    this.service.getAllProducts().subscribe((data) => {
      this.ProductList = data;
    });
  }

  SearchProduct() {
    if (this.searchType == 'id')
      this.service.getProductById(+this.searchValue).subscribe((data) => {
        if ([data]=== null)
        {
          alert("empty")
        }
        else
        this.ProductList = [data];
      });
    else
      this.service.getProductByName(this.searchValue).subscribe((data) => {
        this.ProductList = [data];
      });
  }

  handleInput(event : any):void{
    const numberOnlyRegex = /^[0-9\s]*$/;
    if(this.searchType === 'id' && !numberOnlyRegex.test(event.target.value)){
      event.target.value = this.searchValue;
    }else{
      this.searchValue = event.target.value;
    }
  }

  clearSearch():void{
    this.searchInput.nativeElement.value = '';
    this.searchValue = '';
  }

  searchBy(mode : string) :void{
    this.searchType = mode;
  }
  
  

}
