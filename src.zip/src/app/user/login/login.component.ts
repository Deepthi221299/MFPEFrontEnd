import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
    formModel={
        UserName:'',
        Password:''
      }
      userDetails:any=[];
        constructor(private service:AuthenticationService,private router:Router) { }
      
        ngOnInit(): void {
          // if(localStorage.getItem('token')!=null)
          // this.router.navigate(['Product']);
        }
      onSubmit(form:NgForm)
      {
        this.service.authenticationUser(form.value).subscribe(
        (res:any)=>{
          if(res!="Agent Not Found")
          {
            localStorage.setItem('token',res);
            localStorage.setItem('id',this.formModel.UserName);
            localStorage.setItem('username',this.formModel.Password);
            this.router.navigateByUrl('/Product');
          }
        }
      );
      }
  }
