import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthorizationGuard } from './auth/authorization.guard';
import { CartComponent } from './cart/cart.component';
import { ProductComponent } from './product/product.component';
import { LoginComponent } from './user/login/login.component';
import { UserComponent } from './user/user.component';
import { VendorComponent } from './vendor/vendor.component';
import { WishlistComponent } from './wishlist/wishlist.component';

const routes: Routes = [
  {
    path: 'Product',
    component: ProductComponent,
     canActivate: [AuthorizationGuard],
  },
  {
    path: 'Vendor',
    component: VendorComponent,
    //canActivate: [AuthorizationGuard],
  },
  {
    path: 'Wishlist',
    component: WishlistComponent,
    //canActivate: [AuthorizationGuard],
  },
  { path: 'Cart', component: CartComponent },
  {
    path: 'user',
    component: UserComponent,
    children: [
      {
        path: 'login',
        component: LoginComponent,
      },
    ],
  },
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
