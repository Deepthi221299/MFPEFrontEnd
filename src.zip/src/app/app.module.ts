import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { VendorComponent } from './vendor/vendor.component';
import { ProductService } from './services/product.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { VendorService } from './services/vendor.service';
import { LoginComponent } from './user/login/login.component';
import { UserComponent } from './user/user.component';
import { CartComponent } from './cart/cart.component';
import { AddvendorComponent } from './vendor/addvendor/addvendor.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { AddtocartComponent } from './addtocart/addtocart.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatRadioModule } from '@angular/material/radio';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDividerModule } from '@angular/material/divider';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatSidenavModule } from '@angular/material/sidenav';
import {MatMenuModule} from '@angular/material/menu';
import {MatDialogModule} from '@angular/material/dialog';
import {MatIconModule} from '@angular/material/icon';
import { RemarksDialogComponent } from './remarksdialog/remarksdialog.component';

@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    VendorComponent,
    LoginComponent,
    UserComponent,
    CartComponent,
    AddvendorComponent,
    WishlistComponent,
    AddtocartComponent,
    RemarksDialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatRadioModule,
    MatInputModule,
    MatButtonModule,
    MatTableModule,
    MatSnackBarModule,
    MatDividerModule,
    MatToolbarModule,
    MatCardModule,
    MatSidenavModule,
    MatDialogModule,
    MatIconModule
  ],
  providers: [ProductService, VendorService],
  bootstrap: [AppComponent],
})
export class AppModule {}