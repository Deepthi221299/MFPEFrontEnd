export interface Carts{
        cartId :number;
        customerId :number;
        productId :number;
        zipcode :number;
        quantity:number;
        deliveryData:Date;
        vendorId :number;
}

  