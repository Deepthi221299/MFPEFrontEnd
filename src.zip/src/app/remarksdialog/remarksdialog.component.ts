import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";


@Component({
    selector: 'remarks-dialog',
    templateUrl: './remarksdialog.component.html',
    styleUrls: ['./remarksdialog.component.css']
  
  })
  export class RemarksDialogComponent {
    constructor(@Inject(MAT_DIALOG_DATA) public data: any,public dialogRef: MatDialogRef<RemarksDialogComponent>) {
    }
    public rate(rating: number , product : any) {
      product.stars = (product.stars as any[]).map((_, i) => rating > i);
      product.rating = rating;
    }
  }
    